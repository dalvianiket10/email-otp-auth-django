import random
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import User, OTP
from .serializers import RegisterSerializer, OTPRequestSerializer, OTPVerifySerializer
from django.utils import timezone
from datetime import timedelta
import jwt

SECRET = 'secret123'

class RegisterView(APIView):
    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            return Response({"message": "User registered!"}, status=201)
        return Response(serializer.errors, status=400)

class OTPRequestView(APIView):
    def post(self, request):
        serializer = OTPRequestSerializer(data=request.data)
        if serializer.is_valid():
            email = serializer.validated_data['email']
            code = f"{random.randint(100000, 999999)}"
            OTP.objects.create(email=email, code=code)
            print(f"Mock Email Sent to {email}: Your OTP is {code}")
            return Response({"message": "OTP sent to your email!"}, status=200)
        return Response(serializer.errors, status=400)

class OTPVerifyView(APIView):
    def post(self, request):
        serializer = OTPVerifySerializer(data=request.data)
        if serializer.is_valid():
            email = serializer.validated_data['email']
            code = serializer.validated_data['code']
            otp_records = OTP.objects.filter(email=email, code=code)
            if not otp_records.exists():
                return Response({"error": "Invalid OTP"}, status=400)
            otp = otp_records.latest('created_at')
            if timezone.now() - otp.created_at > timedelta(minutes=10):
                return Response({"error": "OTP expired"}, status=400)

            user, _ = User.objects.get_or_create(email=email)
            user.is_active = True
            user.save()

            token = jwt.encode({'email': email}, SECRET, algorithm='HS256')
            return Response({"message": "OTP verified", "token": token}, status=200)

        return Response(serializer.errors, status=400)
